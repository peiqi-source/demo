



clear all;
clc;

% rand('twister',1400)
folder_now = pwd;
addpath([folder_now,'\function']);
%addpath([folder_now,'\datasets']);



load data_twomoon.mat

numAnchor =6;
numNearestAnchor = 5;
C = length(unique(Y));
mu = 0.01;
rho = 1.01;

gama1=[1e-6,1e-5,1e-4,1e-3,1e-2,1e-1];
gama2_per=[0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9];

[B,Anchor] = ULGE(X,numAnchor,numNearestAnchor);
[n,m]=size(B); 

cnt=0;
for i=1:length(gama1)
    cnt=cnt+1;
    for j = 1:length(gama2_per)
        
        tic
        BB= max(eig(B'*B));
        gama2= floor(gama2_per(j)*BB);       
        D=gama1(i)*B'*ones(n,1)*ones(n,1)'*B+gama2*eye(m)-(B'*B);
        [U,Beta,obj] = SimplexQP_ALM(D,B,C,mu,rho);
        F= B*U;
        [~,Res] = max(F');
        [Acc, NMI, Purity] = ClusteringMeasure(Y, Res');
        [ARI,RI,MI,HI] = RandIndex(Y,Res');
        time = toc;
        
        OBJ{(cnt-1)*length(gama2_per)+j,1}=time;
        OBJ{(cnt-1)*length(gama2_per)+j,2}=Acc;
        OBJ{(cnt-1)*length(gama2_per)+j,3}=NMI;
        OBJ{(cnt-1)*length(gama2_per)+j,4}= Purity;
        OBJ{(cnt-1)*length(gama2_per)+j,5}=ARI;
        OBJ{(cnt-1)*length(gama2_per)+j,6}=gama1(i);
        OBJ{(cnt-1)*length(gama2_per)+j,7}=gama2_per(j);
        
    end
    
end





