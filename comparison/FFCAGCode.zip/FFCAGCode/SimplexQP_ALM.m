function [U,beta,obj] = SimplexQP_ALM(D,B,C,mu,rho)
% solve:
% min     x'Ax - b'x
% s.t.    x'1 = 1, x >= 0
% paras:
% mu    - mu > 0
% beta  - 1 < beta < 2
%
NITER = 5000;
THRESHOLD = 1e-6;
[n,m] = size(B);
sigma = ones(m,C);
A = zeros(m,C);
cnt = 0;
beta = initfcm(m,C);

for iter = 1:NITER
    Z = D*beta;
    for i = 1:m
        dd(i,:) = beta(i,:) -(sigma(i,:)+Z(i,:))/mu;
        A(i,:) =  EProjSimplex(dd(i,:));
    end
    U = A;
    beta=(-D'*U+mu*U+sigma)/mu;
    Beta{iter}=beta;
    sigma = sigma + mu*(U - beta);
    mu = rho*mu;
    obj(iter)=norm(U-beta,'fro').^2;%
    
    if obj(iter) < THRESHOLD
        if cnt >= 5
            break;
        else
            cnt = cnt + 1;
        end
    else
        cnt = 0;
    end
   
end


end