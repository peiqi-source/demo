function [U,beta,obj] = SimplexQP_ALM(Anchor,D1,B,C,mu,rho,gama1,gama2,CI)
% solve:
% min     x'Ax - b'x
% s.t.    x'1 = 1, x >= 0
% paras:
% mu    - mu > 0
% beta  - 1 < beta < 2
%
NITER = 5000;
THRESHOLD = 1e-8;
[n,m] = size(B);
sigma = ones(m,C);
A = zeros(m,C);
cnt = 0;
beta = initfcm(m,C);
% beta = CAN(Anchor',C);
for iter = 1:NITER
    D = (D1)*beta;
    for i = 1:m
        dd(i,:) =beta(i,:) -(sigma(i,:)+D(i,:))/mu;
        A(i,:) =  EProjSimplex(beta(i,:) -(sigma(i,:)+D(i,:))/mu);
    end
    DD{iter} = dd;
    U = A;
    beta=(-D1'*U+mu*U+sigma)/mu;
    Beta{iter}=beta;
    sigma = sigma + mu*(U - beta);
    mu = rho*mu;
    obj22(iter)=(trace(U'*D1*beta))+(mu/2)*norm(U-beta+sigma/mu,'fro').^2;
    obj(iter)=norm(U-beta,'fro').^2;%
%     if iter>1
%         if abs(obj22(iter)-obj22(iter-1) )< THRESHOLD
        if obj(iter) < THRESHOLD
            if cnt >= 5
                break;
            else
                cnt = cnt + 1;
            end
        else
            cnt = 0;
       end
%     end
end


end