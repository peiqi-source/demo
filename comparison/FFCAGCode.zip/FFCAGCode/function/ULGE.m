% X:num*dim
%alpha:regulization num
%numanchor:the real number of anchors is 2^numAnchor
%[1] F. Nie, W. Zhu, and X. Li, "Unsupervised Large Graph Embedding," AAAI2017.
%[2] W. Zhu, F. Nie, and X. Li, "Fast Spectral Clustering with Efficient Large
%Graph Construction," ICASSP2017.
function [Z,M] = ULGE(X,numAnchor,numNearestAnchor)

[num,d] = size(X);

[~,locAnchor] = hKM(X',[1 :num],numAnchor,1); % here we use BKHK algorithm proposed in [2] to generate anchors.
M=locAnchor';

Z = ConstructA_NP(X',(locAnchor),numNearestAnchor);
end