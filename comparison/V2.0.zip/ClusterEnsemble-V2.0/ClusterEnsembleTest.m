% Cluster ensemble on a set of 5 labelings (from 8D5K)
%
% This test basically does the following
%   % load the data
%   load lf8d5k.txt
%   % perform cluster ensemble algorithm
%   cl = clusterensemble(lf8d5k(2:6,:));
%   % compare to the 'correct' labels
%   evalmutual(lf8d5k(1,:),cl);
%   % in this case getting 997/1000 labels right results
%   % in a mutual info of approximately 0.98913

function ClusterEnsembleTest(file, order, N)

% [data,target] = load_letterRecognition();
addpath('Measures');
now = load(file);
filename = file(1:length(file)-4);
data = now.X;
cn = now.Y;
newData = mapminmax(data', 0, 1);
data = newData';
cls=[];
% 
K = length(unique(cn));
for i=1:N
    tmpRes = kmeans(data,K);
    cls=[cls;tmpRes'];
end

NMI_c = [];
Acc_c = [];
ARI_c = [];
Nen_c = [];
NMI_h = [];
Acc_h = [];
ARI_h = [];
Nen_h = [];
NMI_m = [];
Acc_m = [];
ARI_m = [];
Nen_m = [];


% Combine them using k=5
for i = 1:10
    cl = clusterensemble(cls, K);
    result_c = ClusteringMeasure(cn', cl(1, :)');
    result_h = ClusteringMeasure(cn', cl(2, :)');
    result_m = ClusteringMeasure(cn', cl(3, :)');
    NMI_c = [NMI_c, result_c(2)];
    NMI_h = [NMI_h, result_h(2)];
    NMI_m = [NMI_m, result_m(2)];
    
    Acc_c = [Acc_c, cluster_acc(cn', cl(1, :)')];
    Acc_h = [Acc_h, cluster_acc(cn', cl(2, :)')];
    Acc_m = [Acc_m, cluster_acc(cn', cl(3, :)')];
    
    ARI_c = [ARI_c, RandIndex(cn', cl(1, :)')];
    ARI_h = [ARI_h, RandIndex(cn', cl(2, :)')];
    ARI_m = [ARI_m, RandIndex(cn', cl(3, :)')];
    
    Nen_c = [Nen_c, Nentro(cl(1, :), K)];
    Nen_h = [Nen_h, Nentro(cl(2, :), K)];
    Nen_m = [Nen_m, Nentro(cl(3, :), K)];

end
C = [mean(NMI_c); std(NMI_c); mean(Acc_c); std(Acc_c); mean(ARI_c); std(ARI_c); mean(Nen_c); std(Nen_c)];
H = [mean(NMI_h); std(NMI_h); mean(Acc_h); std(Acc_h); mean(ARI_h); std(ARI_h); mean(Nen_h); std(Nen_h)];
M = [mean(NMI_m); std(NMI_m); mean(Acc_m); std(Acc_m); mean(ARI_m); std(ARI_m); mean(Nen_m); std(Nen_m)];
xlswrite(filename, C, order, 'A1');
xlswrite(filename, H, order, 'B1');
xlswrite(filename, M, order, 'C1');