function NenVal = Nentro(Y, K)
%NENTRO 此处显示有关此函数的摘要
%   此处显示详细说明
counts = hist(Y, 1:K);
temp = counts/sum(counts);
temp(temp==0) = [];
NenVal = -1/(log(K)) * sum(temp.*log(temp));
end

