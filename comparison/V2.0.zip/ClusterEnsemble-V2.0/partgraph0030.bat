shmetis graph222 70 5
