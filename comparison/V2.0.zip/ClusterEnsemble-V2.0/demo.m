clear;
clc;

addpath('..\datass');
fileList = dir('..\datass\*.mat');

len = length(fileList);
for i = 1:len
    file = fileList(i).name;
    ClusterEnsembleTest(file, 1, 20);
end
